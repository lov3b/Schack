# Schack
Multiplayer LAN chess written in Java
