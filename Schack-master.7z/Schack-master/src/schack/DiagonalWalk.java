package schack;

public interface DiagonalWalk {

    default void walDiagonal(Piece[][] pieces){
        
    };

}
